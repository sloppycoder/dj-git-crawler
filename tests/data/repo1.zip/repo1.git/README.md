## Extract data form SQL query to write to fixed width text files


### TO DO:
1. error handling with report writer class
2. explain plan