package com.sc.rcr.fico;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import net.sf.flatpack.writer.Writer;
import org.jdom.JDOMException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Component;

@Component
public class EmpReportWriter extends ReportWriter {

	private static final Logger logger = LoggerFactory.getLogger(EmpReportWriter.class);

	@Value("$report-writer.emp.output-path")
	String outputPath;

	@Override
	void writeRowToOutput(ResultSet rs, Writer writer) throws SQLException, IOException, JDOMException {
		// processing columns with special handling
		Float sal = rs.getFloat("SAL");
		writer.addRecordEntry("SAL", String.format("%4.2f", sal));

		// call method to write columns with string values
		// assumes the column names in SQL are the same as in pzmap.xml
		writeStringColumns(rs, new String[] {"SAL"});

		writer.nextRecord();
	}

	void run() {
		FileWriter outputWriter = null;
		try {
			outputWriter = new FileWriter(new File(outputPath + "/test_out.txt"));
			String sql = "select empno, ename, job, mgr, sal from emp where job = :job";
			MapSqlParameterSource params = new MapSqlParameterSource();
			params.addValue("job", "MANAGER", Types.VARCHAR);
			init("emp", outputWriter, false);
			execute(sql, params);
		}
		catch (IOException e) {
			logger.warn("Unable to create output file");
		}
		finally {
			if (outputWriter != null) {
				try {
					outputWriter.close();
				}
				catch (IOException e) {
				}
			}
		}

	}

}
