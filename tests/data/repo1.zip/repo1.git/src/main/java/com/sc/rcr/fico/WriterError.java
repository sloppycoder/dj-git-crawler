package com.sc.rcr.fico;

public class WriterError extends Exception {
	public WriterError(String message) {
		super(message);
	}

	public WriterError(Throwable t) {
		super(t);
	}

	public WriterError(String message, Throwable t) {
		super(message, t);
	}
}
