package com.sc.rcr.fico;

import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import net.sf.flatpack.writer.FixedWriterFactory;
import net.sf.flatpack.writer.Writer;
import org.jdom.JDOMException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

public abstract class ReportWriter {

	private static final Logger logger = LoggerFactory.getLogger(ReportWriter.class);

	private String reportFormat;
	private FileWriter outputWriter;
	private Writer recordWriter;
	private String sql;
	private boolean runExplainPlan = false;
	private boolean processing = false;
	private int batchSize = 1;

	// stats
	private int fetched = 0;
	private int written = 0;
	private int error = 0;

	@Autowired
	private NamedParameterJdbcTemplate jdbcTemplate;

	protected void init(String reportFormat, FileWriter outputWriter, boolean runExplainPlan) {
		this.reportFormat = reportFormat;
		this.outputWriter = outputWriter;
		this.runExplainPlan = runExplainPlan;
	}

	public void execute(String sql, SqlParameterSource params) {
		this.sql = sql;
		this.processing = true;

		jdbcTemplate.query(sql, params, new RowCallbackHandler() {
			@Override
			public void processRow(ResultSet rs) throws SQLException {
				fetched++;
				try {
					Writer writer = getRecordWriter();
					writeRowToOutput(rs, writer);

					written++;

					if (written % batchSize == 0) {
						writer.flush();
					}
				}
				catch (IOException | JDOMException e) {
					logger.warn("cannot flush writer", e);
					throw new RuntimeException(e);
				}
			}
		});

		this.processing = false;
		logger.info("finished processing, {} rows fetched, {} written, {} errors",
				fetched, written, error);
	}

	public void writeStringColumns(ResultSet rs, String[] blacklist) throws IOException, JDOMException, SQLException {
		List<String> excludedColumns = Arrays.asList(blacklist == null ? new String[] {} : blacklist);

		Writer writer = getRecordWriter();
		ResultSetMetaData meta = rs.getMetaData();
		for (int i = 1; i <= meta.getColumnCount(); i++) {
			String columnName = meta.getColumnName(i);
			if (!excludedColumns.contains(columnName)) {
				String value = rs.getString(i);
				writer.addRecordEntry(columnName, value);
			}
		}
	}

	abstract void writeRowToOutput(ResultSet rs, Writer writer) throws SQLException, IOException, JDOMException;

	private Writer getRecordWriter() throws IOException, JDOMException {

		if (recordWriter != null) {
			return recordWriter;
		}

		String pzXml = ApplicationUtils.stromgFromResource(reportFormat + ".pzmap.xml");
		recordWriter = new FixedWriterFactory(new StringReader(pzXml)).createWriter(outputWriter);
		return recordWriter;
	}

	public String getReportFormat() {
		return reportFormat;
	}

	public FileWriter getOutputWriter() {
		return outputWriter;
	}

	public String getSql() {
		return sql;
	}

	public boolean isRunExplainPlan() {
		return runExplainPlan;
	}

	public boolean processing() {
		return processing;
	}
}
