package com.sc.rcr.fico;

import java.io.IOException;
import java.nio.charset.Charset;

import org.springframework.core.io.ClassPathResource;
import org.springframework.util.StreamUtils;

public abstract class ApplicationUtils {

	public static String stromgFromResource(String fileName) {

		try {
			String payload = StreamUtils.copyToString(
					new ClassPathResource(fileName).getInputStream(), Charset.defaultCharset());
			return payload;
		}
		catch (IOException e) {
			return null;
		}
	}
}
